# Aria — voice support agent for Aura Skincare

A browser-based voice agent. The customer clicks **Start call**, talks to Aria through the microphone, and hears her reply. Aria answers brand and policy questions, looks up and cancels orders through tool calls, and the app shows a transcript and a JSON outcome when the call ends.

- **Live app:** `<add your deployed URL>`
- **Demo video:** `<add your video link>`

Use Chrome or Edge on desktop and allow microphone access. Microsoft Edge has the best Indian-English voices.

## How it works

```
mic ──► Web Speech API (speech to text, en-IN)
          │  text
          ▼
     POST /api/chat ──► Express ──► Gemini (function calling)
                                      │   loops: model → get_order_details / cancel_order → model
          ▲  reply text               ▼
speaker ◄─ speechSynthesis (Indian voice)
call end ─► POST /api/summary ─► Gemini (JSON mode) ─► transcript + outcome JSON
```

| File | What it does |
| --- | --- |
| `server.js` | Express server. `/api/chat` runs one customer turn and the tool loop, `/api/summary` builds the post-call JSON. Keeps the API key on the server, falls back to other Gemini models on 429/503, rate limits per IP. |
| `orders.js` | Mock order database and the policy rules (cancellable only while Processing, 7-day return window). Per-call state, so a cancellation in one call never affects the next. |
| `agent.js` | Persona, brand facts, guardrails, tool schemas and the summary prompt. |
| `public/app.js` | The call itself: speech in/out, state indicator, yes/no handling, silence timeouts, interruption, transcript and summary. |
| `public/dialog.js` | Pure text helpers: reads a "no / yes / hmm" answer to the closing question, and spots Aria's own voice coming back through the mic. Unit tested. |
| `test/` | `npm test` runs the unit tests for the order policy and the dialog helpers. |

### Call flow details

- **Closing question.** After each answer Aria asks "Is there anything else I can help you with today?". The app (not the model) interprets the next answer: "no", "no thank you", "that's all", "nahi bas" end the call; "yes" continues; "Yes, can you tell me about COD?" is passed to the model as a normal question; hesitation like "hmm, actually…" gets "Sorry, I didn't catch that. Would you like help with anything else?" and the call stays open. Yes/No buttons appear after a few seconds as a backup.
- **Ending a call.** Aria says goodbye, the microphone stops, the state returns to Idle, and the outcome JSON and transcript appear.
- **Silence.** 20 seconds of silence after the closing question ends the call. At other points Aria checks in after 40 seconds and ends the call if there is still no answer.
- **Echo handling.** The microphone is switched off while Aria speaks (unless interruption is enabled) and restarts shortly after. Anything the recogniser still returns that mostly matches what Aria just said is discarded. This works with any voice.
- **Interruption.** Ticking "Let me interrupt (headphones)" keeps the microphone open while Aria talks and stops her as soon as the customer starts speaking. Use headphones; on speakers her own voice can trigger it.
- **Order state.** Each call gets its own session id, so cancelling ORD-103 in one test does not change it for the next call.

## Run locally

```
npm install
cp .env.example .env      # then paste your key from https://aistudio.google.com/apikey
npm start                 # http://localhost:3000
npm test                  # unit tests
```

Open the app through `http://localhost:3000`. Opening `public/index.html` directly from disk shows the page, but the calls to `/api/chat` need the server.

## Deploy (Render)

New Web Service → connect the repo → Build `npm install` → Start `npm start` → add environment variables `GEMINI_API_KEY` and `GEMINI_MODEL`. Render serves over HTTPS, which browsers require for microphone access.

## Guardrails

1. The system prompt limits Aria to Aura Skincare topics and to the brand facts listed in it, and tells her not to promise refunds, exceptions or delivery times beyond policy.
2. Order data and eligibility come from the tool. `get_order_details` returns `policy` fields computed in code (for example `return_eligible: false` for a 14-day-old order), and the prompt tells Aria to trust them over what the customer claims.
3. Cancelling needs two things: the tool shows the order is Processing, and the customer clearly confirms. If they hesitate, nothing is cancelled.
4. Unknown or missing order IDs return a structured error, and Aria asks the customer to repeat or verify the ID instead of guessing.
5. Shipping at exactly ₹499: the policy says free delivery "above ₹499", so an order of exactly ₹499 pays ₹50.

## Testing it

The page lists the three test orders and has "Try saying" buttons for the main cases: order tracking, a return outside the window, cancelling a Processing order, cancelling an order that is already out, no order ID, unknown order, COD limit, shipping, Hinglish and an out-of-scope request.

## Known limits

- Speech recognition uses the browser's built-in service, so it needs Chrome or Edge and an internet connection, and accuracy on Indian-English and Hinglish varies.
- Voices are the ones installed in the browser. Latency is a full round trip per turn (recognise, model, speak), not streaming.
- The order database is in memory and resets when the server restarts.

## Thinking behind it

**1. Why this architecture and stack?**
I wanted something an evaluator can open and use immediately, with no accounts, telephony or audio servers. The browser already provides speech recognition and speech synthesis with Indian voices, so the server only has to do the part that needs secrets and logic: one Gemini call per turn with function calling, plus the order tools. The speech layer is separate from the model layer, so either can be swapped. I accepted higher latency and no streaming in exchange for reliability and zero cost.

**2. What was the hardest part?**
Turn-taking. In a browser the microphone hears the speaker, so Aria would answer her own voice, mistake her own closing question for the customer, and never end the call. I fixed it in layers: the microphone is paused while she speaks, results that match her recent words are dropped, and the yes/no decision is made by a small classifier in the app instead of leaving it to the model. Interruption uses a volume detector so she stops immediately instead of waiting for recognised text, and the conversation history is trimmed to what she had actually said.

**3. What would I improve first with one more week?**
A scripted evaluation suite of calls (policy pushback, mumbling, prompt injection, Hinglish) run against the real model, because prompt changes can quietly break behaviour that I currently check by hand. After that, a streaming speech-to-speech or cloud speech pipeline for lower latency, proper echo cancellation and a more natural Indian voice.

**4. What would change at 1,000 calls a day?**
Caller verification (OTP or phone match) before sharing order details, since anyone who knows an ID can look it up today. A real database for orders and call records with PII redaction, per-session cost and rate limits, and monitoring of latency, tool errors and escalation rate. I would also add a human handoff path for unresolved calls, provider fallbacks for speech and the model, load testing, and automated regression evals before every prompt change.
