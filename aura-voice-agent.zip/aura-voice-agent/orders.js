// Mock order database and the policy rules that go with it.
// Eligibility is decided here in code, so the model only reports what the tool returns.

export const ORDERS = {
  "ORD-101": {
    order_id: "ORD-101", customer: "Priya Sharma", product: "Vitamin C Serum (30ml)", value: 699,
    status: "Out for Delivery", carrier: "BlueDart", tracking_id: "BD-982103", note: "Expected by 6 PM today",
  },
  "ORD-102": {
    order_id: "ORD-102", customer: "Rahul Verma", product: "Hydrating Sunscreen SPF 50", value: 499,
    status: "Delivered", carrier: "Delhivery", tracking_id: "DL-441029", delivered_days_ago: 14, note: "Delivered 14 days ago",
  },
  "ORD-103": {
    order_id: "ORD-103", customer: "Ananya Patel", product: "Green Tea Face Wash + Toner", value: 850,
    status: "Processing", note: "Ordered 3 hours ago. Eligible for cancellation",
  },
};

// "ord 101", "O R D 1 0 1", "101" and "ORD-101" all map to "ORD-101".
export function normalizeOrderId(raw = "") {
  const digits = String(raw).replace(/\D/g, "");
  return digits ? `ORD-${digits}` : null;
}

function policyFor(o) {
  const processing = o.status === "Processing";
  const inTransit = ["Shipped", "Out for Delivery"].includes(o.status);
  const policy = {
    can_cancel: processing,
    cancel_note: processing
      ? "Cancellable now."
      : inTransit
        ? "Cannot be cancelled once shipped. Customer may refuse delivery at the doorstep."
        : `Cannot be cancelled (status: ${o.status}).`,
  };

  if (o.status === "Delivered") {
    const within = o.delivered_days_ago <= 7;
    policy.return_eligible = within; // still needs unopened, unused, original packaging
    policy.return_note = within
      ? "Within the 7-day window; only valid if unopened, unused and in original packaging. Ask the customer."
      : `Delivered ${o.delivered_days_ago} days ago, outside the 7-day return window. Do NOT promise a return or refund. Damaged or defective items had to be reported within 48 hours of delivery.`;
  } else if (o.status === "Cancelled") {
    policy.return_eligible = false;
    policy.return_note = "This order was cancelled, so there is nothing to return.";
  } else {
    policy.return_eligible = false;
    policy.return_note = "Order not delivered yet, so no return is possible. Cancellation rules apply instead.";
  }
  return policy;
}

// `state` holds changes made during one call (for example a cancellation),
// so one caller cancelling ORD-103 never changes it for the next caller.
function lookup(id, state) {
  const base = ORDERS[id];
  return base ? { ...base, ...(state[id] || {}) } : null;
}

export function getOrderDetails(raw, state = {}) {
  const id = normalizeOrderId(raw);
  if (!id) return { found: false, error: "MISSING_OR_UNREADABLE_ORDER_ID" };
  const order = lookup(id, state);
  if (!order) return { found: false, error: "ORDER_NOT_FOUND", order_id: id };
  return { found: true, ...order, policy: policyFor(order) };
}

export function cancelOrder(raw, state = {}) {
  const d = getOrderDetails(raw, state);
  if (!d.found) return { success: false, ...d };
  if (!d.policy.can_cancel) return { success: false, order_id: d.order_id, reason: d.policy.cancel_note };
  state[d.order_id] = { status: "Cancelled", note: "Cancelled during this call" };
  return { success: true, order_id: d.order_id, message: "Order cancelled." };
}
