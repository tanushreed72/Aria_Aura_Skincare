(() => {
  const $ = (s) => document.querySelector(s);
  const SR = window.SpeechRecognition || window.webkitSpeechRecognition;

  const GREETING = "Hello! This is Aria from Aura Skincare. How can I help you today?";
  const FAREWELL = "Thank you for calling Aura Skincare. Have a wonderful day!";
  const IDLE_FAREWELL = "I haven't heard anything, so I'll end the call here. Thank you for contacting Aura Skincare.";
  const REPROMPT = "Sorry, I didn't catch that. Would you like help with anything else?";
  const CONTINUE_REPLY = "Sure, go ahead.";
  const NUDGE = "Are you still there? I'm happy to help whenever you're ready.";
  const ERROR_REPLY = "Sorry, I'm having a technical problem right now. Please try again in a moment.";

  const CLOSING_IDLE_MS = 20000; // silence after "anything else?" before the call is closed
  const GENERAL_IDLE_MS = 40000; // silence at any other point before Aria checks in
  const NUDGE_GRACE_MS = 20000; // silence after the check-in before the call is closed
  const BUTTONS_AFTER_MS = 6000; // yes/no buttons show up if the caller hasn't answered by voice
  const MIC_RESUME_MS = 350; // pause before listening again so the tail of Aria's voice isn't picked up
  const ECHO_TAIL_MS = 2500; // how long after Aria stops that her words may still arrive from the recogniser
  const CHAT_TIMEOUT_MS = 25000;
  const SEND_DELAY_MS = 350; // wait after the last final result before sending the turn

  const MORE =
    /anything else|any other (question|help|thing)|something else|kuch aur|aur kuch|kisi aur (cheez|cheese|baat|kaam|sawaal|sawal)|madad kar sakti/i;
  const BYE =
    /have a (wonderful|great|nice|lovely|good|pleasant) (day|evening|one)|aapka din shubh|goodbye|take care|phir milenge|thank you for (calling|contacting)/i;

  let active = false;
  let closing = false;
  let muted = false;
  let speaking = false;
  let busy = false;
  let awaitingMore = false;
  let micWanted = false;

  let rec = null;
  let vad = null;
  let voices = [];
  let history = [];
  let transcript = [];
  let actions = [];
  let pending = [];
  let spokenLog = [];

  let callId = 0;
  let sessionId = "";
  let finalBuf = "";
  let sendTimer;
  let idleTimer;
  let buttonTimer;
  let tick;
  let startedAt = 0;
  let speakToken = 0;
  let settleSpeak = null;
  let speechStartedAt = 0;
  let speechEndedAt = 0;
  let sentences = [];
  let spokenCount = 0;
  let lastSummary = null;

  // Some voices read "Aura" as "Cura"; this spelling comes out right and is only used for speech.
  const sayable = (t) => t.replace(/\bAura\b/g, "Awra");

  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  const esc = (s) => String(s).replace(/[<>&]/g, (c) => ({ "<": "&lt;", ">": "&gt;", "&": "&amp;" })[c]);
  const fmt = (s) => String(Math.floor(s / 60)).padStart(2, "0") + ":" + String(s % 60).padStart(2, "0");
  const bargeOn = () => $("#barge").checked;
  const caption = (t) => ($("#caption").textContent = t ? "“" + t + "”" : "");

  function setState(s, label) {
    $("#call").dataset.s = s;
    $("#status").textContent = label;
  }

  const DIGITS = { zero: 0, oh: 0, one: 1, two: 2, three: 3, four: 4, five: 5, six: 6, seven: 7, eight: 8, nine: 9 };

  // The voice reads "O-R-D one-oh-one"; the transcript should show "ORD-101".
  function pretty(t) {
    return t
      .replace(
        /O[-\s]?R[-\s]?D[-\s]+((?:(?:zero|oh|one|two|three|four|five|six|seven|eight|nine)[-\s]?)+)/gi,
        (_, w) => "ORD-" + w.trim().split(/[-\s]+/).map((x) => DIGITS[x.toLowerCase()]).join("")
      )
      .replace(/\b([A-Z])-([A-Z])-([A-Z])\b/g, "$1$2$3")
      .replace(/(\d[\d,]*)\s*rupees/gi, "₹$1");
  }

  function addMsg(role, text, log = true) {
    const shown = role === "aria" ? pretty(text) : text;
    const d = document.createElement("div");
    d.className = "m " + role;
    d.textContent = shown;
    $("#thread").append(d);
    $("#thread").scrollTop = 1e9;
    if (log) transcript.push({ role, text: shown });
  }

  function typing(on) {
    $("#typing")?.remove();
    if (!on) return;
    const d = document.createElement("div");
    d.id = "typing";
    d.className = "typing";
    d.innerHTML = "<i></i><i></i><i></i>";
    $("#thread").append(d);
    $("#thread").scrollTop = 1e9;
  }

  function loadVoices() {
    const all = speechSynthesis.getVoices();
    voices = all.filter((v) => /^(en|hi)/i.test(v.lang));
    if (!voices.length) voices = all;

    const sel = $("#voice");
    const keep = sel.value;
    sel.innerHTML = "";
    voices.forEach((v) => {
      const o = document.createElement("option");
      o.value = v.voiceURI;
      o.textContent = `${v.name} (${v.lang})`;
      sel.append(o);
    });

    if (keep && voices.some((v) => v.voiceURI === keep)) {
      sel.value = keep;
      return;
    }
    // Aria is a woman, so prefer a female Indian-English voice when the browser has one.
    const prefs = [/neerja/i, /heera/i, /veena/i, /kalpana/i];
    const indian = voices.filter((v) => /en[-_]IN/i.test(v.lang));
    const pick =
      prefs.map((re) => indian.find((v) => re.test(v.name))).find(Boolean) || indian[0] || voices[0];
    if (pick) sel.value = pick.voiceURI;
  }

  const currentVoice = () => voices.find((v) => v.voiceURI === $("#voice").value);

  speechSynthesis.onvoiceschanged = loadVoices;
  loadVoices();

  function stopSpeaking() {
    speakToken++;
    speechSynthesis.cancel();
    speaking = false;
    if (settleSpeak) {
      const done = settleSpeak;
      settleSpeak = null;
      done(false);
    }
  }

  // Resolves true when Aria finished the whole message, false if she was cut off.
  function speak(text) {
    return new Promise((resolve) => {
      stopSpeaking();
      const token = speakToken;
      settleSpeak = resolve;

      sentences = (text.match(/[^.!?।]+[.!?।]*/g) || [text]).map((p) => p.trim()).filter(Boolean);
      spokenCount = 0;
      spokenLog.push(text);
      speaking = true;
      speechStartedAt = Date.now();
      setState("speaking", "Aria is speaking");
      if (!bargeOn()) micOff();

      let i = 0;
      const finishAll = () => {
        speaking = false;
        speechEndedAt = Date.now();
        settleSpeak = null;
        if (!bargeOn()) {
          setTimeout(() => {
            if (token === speakToken) micOn();
          }, MIC_RESUME_MS);
        }
        resolve(true);
      };

      const next = () => {
        if (token !== speakToken) return;
        if (i >= sentences.length) return finishAll();
        const idx = i++;
        const u = new SpeechSynthesisUtterance(sayable(sentences[idx]));
        const v = currentVoice();
        if (v) {
          u.voice = v;
          u.lang = v.lang;
        } else {
          u.lang = "en-IN";
        }
        u.rate = 1.03;

        let settled = false;
        // Some browsers never fire onend, which would freeze the call; this moves on regardless.
        const watchdog = setTimeout(advance, 3000 + sentences[idx].length * 110);
        function advance() {
          if (settled) return;
          settled = true;
          clearTimeout(watchdog);
          spokenCount = idx + 1;
          next();
        }
        u.onend = advance;
        u.onerror = advance;
        speechSynthesis.speak(u);
      };

      // Speaking straight after cancel() is dropped by Chrome now and then, so wait a beat.
      setTimeout(() => {
        speechSynthesis.resume();
        next();
      }, 60);
    });
  }

  function initRec() {
    if (!SR) {
      addMsg("sys", "Voice input needs Chrome or Edge. You can still type below.", false);
      return;
    }
    rec = new SR();
    rec.lang = "en-IN";
    rec.continuous = true;
    rec.interimResults = true;
    rec.onresult = onResult;
    rec.onend = () => {
      if (micWanted && active) setTimeout(micOn, 200);
    };
    rec.onerror = (e) => {
      if (/not-allowed|service-not-allowed/.test(e.error)) {
        addMsg("sys", "Microphone is blocked. Allow access in the address bar, or type instead.", false);
      } else if (e.error === "audio-capture") {
        addMsg("sys", "No microphone was found. You can type instead.", false);
      } else if (e.error === "network") {
        addMsg("sys", "Speech recognition lost its connection. You can type instead.", false);
      }
    };
  }

  function micOn() {
    if (!rec || !active || closing || muted) return;
    micWanted = true;
    try {
      rec.start();
    } catch {
      // already running
    }
  }

  function micOff() {
    micWanted = false;
    finalBuf = "";
    caption("");
    try {
      rec?.abort();
    } catch {
      // not running
    }
  }

  // Aria's own voice leaking back into the mic is the main source of phantom replies.
  function isAriaEcho(text) {
    const recent = spokenLog.slice(-2);
    if (!recent.length) return false;
    if (speaking) return Dialog.looksLikeEcho(text, recent, { minWords: 2, ratio: 0.6 });
    if (Date.now() - speechEndedAt < ECHO_TAIL_MS) return Dialog.looksLikeEcho(text, recent, { minWords: 3, ratio: 0.8 });
    return false;
  }

  function onResult(e) {
    if (!active || muted || closing) return;

    let fresh = "";
    let interim = "";
    for (let i = e.resultIndex; i < e.results.length; i++) {
      const r = e.results[i];
      const chunk = r[0].transcript.trim();
      if (!chunk || isAriaEcho(chunk)) continue;
      if (r.isFinal) fresh += " " + chunk;
      else interim += " " + chunk;
    }

    const heard = (fresh + " " + interim).trim();
    if (!heard) return;

    if (speaking) {
      // Anything that isn't Aria's own voice while she talks is the caller cutting in.
      if (bargeOn() && heard.length > 2) interrupt();
      else return;
    }

    finalBuf += fresh;
    caption((finalBuf + " " + interim).trim());
    noteActivity();
    clearTimeout(sendTimer);
    if (finalBuf.trim()) sendTimer = setTimeout(flush, SEND_DELAY_MS);
  }

  function flush() {
    const t = finalBuf.trim();
    finalBuf = "";
    caption("");
    if (t) handleUser(t);
  }

  // Keep the conversation history honest: Aria only said what the caller actually heard.
  function interrupt() {
    if (!speaking) return;
    const last = history[history.length - 1];
    const lastSpoken = spokenLog[spokenLog.length - 1];
    if (last && last.role === "assistant" && last.text === lastSpoken) {
      const heard = sentences.slice(0, spokenCount).join(" ");
      last.text = (heard ? heard + " " : "") + "(the customer interrupted here)";
    }
    stopSpeaking();
    setState("listening", "Listening…");
  }

  // Energy-based detector so Aria stops talking the moment the caller does, without waiting for text.
  async function startVad() {
    if (vad || !navigator.mediaDevices?.getUserMedia) return;
    const id = callId;
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        audio: { echoCancellation: true, noiseSuppression: true, autoGainControl: true },
      });
      if (id !== callId || !active || !bargeOn()) {
        stream.getTracks().forEach((t) => t.stop());
        return;
      }
      const ctx = new (window.AudioContext || window.webkitAudioContext)();
      await ctx.resume();
      const analyser = ctx.createAnalyser();
      analyser.fftSize = 1024;
      ctx.createMediaStreamSource(stream).connect(analyser);
      const buf = new Float32Array(analyser.fftSize);

      let floor = 0.01;
      let loud = 0;
      const timer = setInterval(() => {
        analyser.getFloatTimeDomainData(buf);
        let sum = 0;
        for (const x of buf) sum += x * x;
        const rms = Math.sqrt(sum / buf.length);

        const warmingUp = speaking && Date.now() - speechStartedAt < 600;
        const trigger = Math.max(0.015, floor * 2);
        if (!speaking || muted || !bargeOn() || warmingUp) {
          floor = floor * (warmingUp ? 0.7 : 0.9) + rms * (warmingUp ? 0.3 : 0.1);
          loud = 0;
          return;
        }
        if (rms < trigger) {
          floor = floor * 0.95 + rms * 0.05;
          loud = 0;
          return;
        }
        if (++loud >= 3) {
          loud = 0;
          interrupt();
        }
      }, 50);

      vad = {
        stop() {
          clearInterval(timer);
          stream.getTracks().forEach((t) => t.stop());
          ctx.close().catch(() => {});
        },
      };
    } catch {
      vad = null;
    }
  }

  function stopVad() {
    vad?.stop();
    vad = null;
  }

  function clearTimers() {
    clearTimeout(idleTimer);
    clearTimeout(buttonTimer);
    clearTimeout(sendTimer);
  }

  function setAwaiting(on) {
    awaitingMore = on;
    if (!on) {
      clearTimeout(buttonTimer);
      $("#more").classList.add("hide");
    }
  }

  function showMore() {
    if (!awaitingMore || !active || closing) return;
    $("#more").classList.remove("hide");
    $("#thread").scrollTop = 1e9;
  }

  // Starts the silence countdown. Anything the caller says or does starts it over.
  function armIdle() {
    if (!active || closing || speaking || busy) return;
    clearTimeout(idleTimer);
    clearTimeout(buttonTimer);
    if (awaitingMore) {
      buttonTimer = setTimeout(showMore, BUTTONS_AFTER_MS);
      idleTimer = setTimeout(() => finish(IDLE_FAREWELL), CLOSING_IDLE_MS);
    } else {
      idleTimer = setTimeout(nudge, GENERAL_IDLE_MS);
    }
  }

  function noteActivity() {
    armIdle();
  }

  async function nudge() {
    if (!active || closing || speaking || busy || awaitingMore) return;
    const id = callId;
    addMsg("aria", NUDGE);
    await speak(NUDGE);
    if (id !== callId || !active || closing) return;
    setState("listening", "Listening…");
    idleTimer = setTimeout(() => finish(IDLE_FAREWELL), NUDGE_GRACE_MS);
  }

  async function handleUser(text) {
    if (!active || closing) return;
    clearTimeout(idleTimer);

    if (awaitingMore) {
      const kind = Dialog.classifyClosing(text);
      if (kind === "no") {
        addMsg("customer", text);
        return finish();
      }
      if (kind === "yes") {
        addMsg("customer", text);
        return keepGoing(text);
      }
      if (kind === "unclear") {
        addMsg("customer", text);
        return reprompt(text);
      }
      setAwaiting(false);
    }

    addMsg("customer", text);
    if (busy) {
      pending.push(text);
      return;
    }
    await ask(text);
  }

  async function ask(text) {
    const id = callId;
    busy = true;
    history.push({ role: "user", text });
    setState("thinking", "One moment…");
    typing(true);

    let reply;
    let failed = false;
    try {
      const ctrl = new AbortController();
      const timeout = setTimeout(() => ctrl.abort(), CHAT_TIMEOUT_MS);
      const r = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ sessionId, messages: history.slice(-30) }),
        signal: ctrl.signal,
      }).finally(() => clearTimeout(timeout));
      const j = await r.json().catch(() => ({}));
      if (!r.ok) throw new Error(j.error || r.status);

      for (const c of j.toolCalls || []) {
        actions.push(c);
        const outcome = c.result?.error ? "error: " + c.result.error : c.result?.success === false ? "refused" : "ok";
        transcript.push({ role: "tool", text: `${c.name}(${JSON.stringify(c.args)}) → ${outcome}` });
      }
      reply = j.reply;
      history.push({ role: "assistant", text: reply });
    } catch (e) {
      console.error(e);
      history.pop();
      reply = ERROR_REPLY;
      failed = true;
    }

    if (id !== callId || !active) return;
    typing(false);
    busy = false;
    addMsg("aria", reply);

    setAwaiting(!failed && MORE.test(reply));
    const endsCall = !awaitingMore && !failed && BYE.test(reply) && !/\?\s*$/.test(reply.trim());

    const finished = await speak(reply);
    if (id !== callId || !active || closing) return;
    if (endsCall && finished) return endCall();

    if (pending.length) return ask(pending.splice(0).join(" "));
    setState("listening", "Listening…");
    armIdle();
  }

  // Yes / no answers to "anything else?" are handled here, not by the model, so they can't be misread.
  async function keepGoing(userText = "Yes, please") {
    const id = callId;
    setAwaiting(false);
    clearTimeout(idleTimer);
    history.push({ role: "user", text: userText }, { role: "assistant", text: CONTINUE_REPLY });
    addMsg("aria", CONTINUE_REPLY);
    await speak(CONTINUE_REPLY);
    if (id !== callId || !active || closing) return;
    setState("listening", "Listening…");
    armIdle();
  }

  async function reprompt(userText) {
    const id = callId;
    clearTimeout(idleTimer);
    history.push({ role: "user", text: userText }, { role: "assistant", text: REPROMPT });
    addMsg("aria", REPROMPT);
    await speak(REPROMPT);
    if (id !== callId || !active || closing) return;
    setState("listening", "Listening…");
    armIdle();
  }

  async function finish(msg = FAREWELL) {
    if (!active || closing) return;
    const id = callId;
    closing = true;
    setAwaiting(false);
    clearTimers();
    micOff();
    addMsg("aria", msg);
    await Promise.race([speak(msg), sleep(9000)]);
    if (id !== callId) return;
    endCall();
  }

  async function startCall() {
    if (active) return;
    const id = ++callId;
    stopSpeaking();
    stopVad();
    clearTimers();

    sessionId = crypto.randomUUID ? crypto.randomUUID() : Date.now() + "-" + Math.random().toString(36).slice(2);
    history = [{ role: "assistant", text: GREETING }];
    transcript = [];
    actions = [];
    pending = [];
    spokenLog = [];
    finalBuf = "";
    busy = false;
    closing = false;
    muted = false;
    awaitingMore = false;
    speechEndedAt = 0;
    setAwaiting(false);
    typing(false);

    $("#thread").innerHTML = "";
    $("#mute").textContent = "Mute";
    $("#mute").classList.remove("on");
    $("#start").classList.add("hide");
    $("#mute").classList.remove("hide");
    $("#end").classList.remove("hide");
    $("#txt").disabled = $("#send").disabled = false;

    active = true;
    startedAt = Date.now();
    $("#timer").textContent = "00:00";
    clearInterval(tick);
    tick = setInterval(() => ($("#timer").textContent = fmt(Math.round((Date.now() - startedAt) / 1000))), 1000);

    initRec();
    if (bargeOn()) {
      micOn();
      startVad();
    }

    addMsg("aria", GREETING);
    await speak(GREETING);
    if (id !== callId || !active || closing) return;
    setState("listening", "Listening…");
    armIdle();
  }

  function endCall() {
    if (!active) return;
    active = false;
    closing = true;
    clearInterval(tick);
    clearTimers();
    stopSpeaking();
    micOff();
    stopVad();
    if (rec) {
      rec.onend = rec.onresult = rec.onerror = null;
      rec = null;
    }
    setAwaiting(false);
    typing(false);
    caption("");
    setState("idle", "Call ended");

    $("#start").textContent = "Start new call";
    $("#start").classList.remove("hide");
    $("#mute").classList.add("hide");
    $("#end").classList.add("hide");
    $("#txt").disabled = $("#send").disabled = true;

    report(Math.round((Date.now() - startedAt) / 1000));
  }

  async function report(secs) {
    $("#modal").classList.remove("hide");
    $("#dur").textContent = "Call length " + fmt(secs);
    $("#json").textContent = "Generating summary…";
    $("#acts").innerHTML = actions.length
      ? actions.map((a) => `<code>${esc(a.name)}(${esc(Object.values(a.args || {}).join(", "))})</code>`).join("")
      : '<span class="mut">None</span>';
    $("#tl").innerHTML = transcript
      .filter((t) => t.role !== "tool")
      .map((t) => `<p><b class="${t.role === "aria" ? "a" : ""}">${t.role === "aria" ? "Aria" : "Customer"}:</b> ${esc(t.text)}</p>`)
      .join("");

    try {
      const ctrl = new AbortController();
      const timeout = setTimeout(() => ctrl.abort(), CHAT_TIMEOUT_MS);
      const r = await fetch("/api/summary", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ transcript }),
        signal: ctrl.signal,
      }).finally(() => clearTimeout(timeout));
      lastSummary = await r.json();
    } catch {
      lastSummary = { error: "SUMMARY_UNAVAILABLE", detail: "Could not reach the server. Check that it is running, then retry." };
    }
    $("#json").textContent = JSON.stringify(lastSummary, null, 2);
  }

  $("#start").onclick = startCall;
  $("#end").onclick = endCall;

  $("#yes").onclick = () => {
    if (!active || closing) return;
    addMsg("customer", "Yes, please");
    keepGoing();
  };
  $("#no").onclick = () => {
    if (!active || closing) return;
    addMsg("customer", "No, that's all");
    finish();
  };

  $("#mute").onclick = () => {
    muted = !muted;
    $("#mute").textContent = muted ? "Unmute" : "Mute";
    $("#mute").classList.toggle("on", muted);
    if (muted) {
      micOff();
      setState("listening", "Muted");
    } else {
      if (!speaking || bargeOn()) micOn();
      if (!speaking && !busy) setState("listening", "Listening…");
    }
  };

  $("#voice").onchange = () => {
    if (!active) return;
    // Drop anything half-heard and restart the recogniser so the new voice starts from a clean slate.
    finalBuf = "";
    caption("");
    if (!speaking) {
      micOff();
      setTimeout(() => {
        if (active && !closing && !speaking) micOn();
      }, 300);
    }
  };

  $("#barge").onchange = () => {
    if (!active || closing) return;
    if (bargeOn()) {
      micOn();
      startVad();
    } else {
      stopVad();
      if (speaking) micOff();
    }
  };

  $("#form").onsubmit = (e) => {
    e.preventDefault();
    const t = $("#txt").value.trim();
    if (!t || !active || closing) return;
    $("#txt").value = "";
    stopSpeaking();
    handleUser(t);
  };

  document.querySelectorAll(".try button").forEach((b) => {
    b.onclick = () => {
      if (!active || closing) {
        $("#status").textContent = "Start a call first";
        return;
      }
      stopSpeaking();
      handleUser(b.dataset.say);
    };
  });

  $("#close").onclick = () => $("#modal").classList.add("hide");
  $("#again").onclick = () => {
    $("#modal").classList.add("hide");
    startCall();
  };
  $("#dl").onclick = () => {
    const a = document.createElement("a");
    a.href = URL.createObjectURL(
      new Blob([JSON.stringify({ summary: lastSummary, transcript }, null, 2)], { type: "application/json" })
    );
    a.download = "aria-call-summary.json";
    a.click();
  };
})();
