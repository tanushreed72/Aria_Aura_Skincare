// Small text helpers used by app.js. Kept free of DOM code so they can be unit tested in Node.
(function () {
  const words = (text) =>
    String(text)
      .toLowerCase()
      .replace(/['’]/g, "")
      .replace(/[^\p{L}\p{N}\s]/gu, " ")
      .split(/\s+/)
      .filter(Boolean);

  const NO_WORDS = new Set([
    "no", "nope", "nah", "nahi", "nahin", "nai", "nothing", "bas", "enough",
    "bye", "goodbye", "done", "thanks", "thank", "dhanyavad", "shukriya", "dhanyawad",
  ]);
  const NO_PHRASES = [
    /\bthats (all|it|everything)\b/,
    /\bthat is (all|it)\b/,
    /\b(im|i am) (good|fine|done|okay|ok)\b/,
    /\ball (good|set|done)\b/,
    /\bitna hi\b/,
    /\bkuch (aur )?nahi\b/,
    /\baur kuch nahi\b/,
  ];
  const YES_WORDS = new Set(["yes", "yeah", "yep", "yup", "yea", "sure", "haan", "han", "ha", "haa"]);

  // Words that may sit next to a plain yes/no without changing its meaning.
  const FILLER = new Set([
    "please", "ok", "okay", "so", "much", "very", "you", "it", "that", "thats", "all", "for", "now",
    "im", "i", "am", "good", "fine", "set", "else", "more", "today", "just", "really", "thank",
    "thanks", "ji", "hi", "hai", "itna", "kuch", "aur", "chahiye", "theek", "bas", "great",
    "nothing", "is", "be", "will", "of", "course", "the", "help", "helpful", "was", "been",
  ]);
  // After a "yes" these still mean "keep going, I'll ask something".
  const YES_EXTRA = new Set([
    "i", "do", "have", "one", "more", "thing", "another", "question", "want", "to", "ask", "actually",
    "theek", "hai", "ji", "a", "there", "is", "something", "else",
  ]);
  // Words that show the caller is about to say more, so "no" must not end the call.
  const CONTINUES = new Set([
    "but", "also", "wait", "however", "another", "question", "actually", "want", "need", "have", "ask",
    "cancel", "return", "order", "track", "where", "what", "how", "can", "could", "tell", "about",
  ]);
  const UNCLEAR = new Set([
    "hmm", "hm", "hmmm", "mm", "mmm", "um", "umm", "uh", "uhh", "er", "ah", "oh", "well", "so",
    "actually", "wait", "ok", "okay", "maybe", "let", "me", "think", "a", "second", "minute", "moment",
    "one", "theek", "hai", "like", "you", "know", "i", "guess",
  ]);

  // Classify what the caller said right after "Is there anything else I can help you with?"
  //   "no"      -> they are done
  //   "yes"     -> they want to continue (no real question yet)
  //   "unclear" -> hesitation only, ask again
  //   "other"   -> a real request, hand it to the model
  function classifyClosing(text) {
    const w = words(text);
    if (!w.length || w.length > 10) return "other";
    const joined = w.join(" ");

    const hasNo = w.some((x) => NO_WORDS.has(x)) || NO_PHRASES.some((re) => re.test(joined));
    const hasYes = w.some((x) => YES_WORDS.has(x));

    if (hasNo && !hasYes) {
      const ok = w.every((x) => NO_WORDS.has(x) || FILLER.has(x));
      const phrase = NO_PHRASES.some((re) => re.test(joined));
      const continues = w.some((x) => CONTINUES.has(x));
      if ((ok || phrase) && !continues) return "no";
      return "other";
    }
    if (hasYes && !hasNo) {
      const ok = w.every((x) => YES_WORDS.has(x) || FILLER.has(x) || YES_EXTRA.has(x));
      return ok ? "yes" : "other";
    }
    if (!hasYes && !hasNo && w.every((x) => UNCLEAR.has(x))) return "unclear";
    return "other";
  }

  function editDistanceAtMostOne(a, b) {
    if (a === b) return true;
    if (Math.abs(a.length - b.length) > 1) return false;
    let i = 0;
    let j = 0;
    let edits = 0;
    while (i < a.length && j < b.length) {
      if (a[i] === b[j]) {
        i++;
        j++;
        continue;
      }
      if (++edits > 1) return false;
      if (a.length > b.length) i++;
      else if (b.length > a.length) j++;
      else {
        i++;
        j++;
      }
    }
    return edits + (a.length - i) + (b.length - j) <= 1;
  }

  // True when most of what the mic picked up is words Aria herself just said.
  // minWords / ratio let the caller be stricter right after she stops than while she talks.
  function looksLikeEcho(heard, ariaTexts, { minWords = 3, ratio = 0.8 } = {}) {
    const hw = words(heard);
    if (hw.length < minWords) return false;
    const pool = [...new Set(ariaTexts.flatMap(words))];
    if (!pool.length) return false;
    const hits = hw.filter((w) => pool.some((p) => p === w || (w.length >= 4 && editDistanceAtMostOne(p, w))));
    return hits.length / hw.length >= ratio;
  }

  globalThis.Dialog = { words, classifyClosing, looksLikeEcho };
})();
