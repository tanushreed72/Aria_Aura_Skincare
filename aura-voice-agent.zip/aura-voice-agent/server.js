import "dotenv/config";
import express from "express";
import path from "path";
import { fileURLToPath } from "url";
import { ORDERS, getOrderDetails, cancelOrder } from "./orders.js";
import { SYSTEM_PROMPT, TOOLS, SUMMARY_PROMPT } from "./agent.js";

const PORT = process.env.PORT || 3000;
const MODELS = [
  ...new Set([process.env.GEMINI_MODEL, "gemini-3.8-flash", "gemini-3.7-flash", "gemini-3.6-flash"].filter(Boolean)),
];
const declarations = TOOLS.map(({ name, description, parameters }) => ({ name, description, parameters }));

const app = express();
app.set("trust proxy", 1);
app.use(express.json({ limit: "1mb" }));
app.use(express.static(path.join(path.dirname(fileURLToPath(import.meta.url)), "public")));

const hits = new Map();
function rateLimit(limit) {
  return (req, res, next) => {
    const now = Date.now();
    const key = req.ip + req.path;
    const recent = (hits.get(key) || []).filter((t) => now - t < 60_000);
    if (recent.length >= limit) {
      return res.status(429).json({ error: "Too many requests. Please wait a moment and try again." });
    }
    recent.push(now);
    hits.set(key, recent);
    next();
  };
}

const sessions = new Map();
function sessionState(id) {
  if (typeof id !== "string" || !id || id.length > 80) return {};
  let s = sessions.get(id);
  if (!s) {
    s = { orders: {}, touched: 0 };
    sessions.set(id, s);
  }
  s.touched = Date.now();
  return s.orders;
}
setInterval(() => {
  const cutoff = Date.now() - 30 * 60_000;
  for (const [id, s] of sessions) if (s.touched < cutoff) sessions.delete(id);
  for (const [key, list] of hits) if (!list.some((t) => Date.now() - t < 60_000)) hits.delete(key);
}, 5 * 60_000).unref();

function thinkingFor(model) {
  if (/gemini-3/.test(model)) return { thinkingLevel: "minimal" };
  if (/gemini-2\.5-flash/.test(model)) return { thinkingBudget: 0 };
  return undefined;
}

function send(model, body) {
  return fetch(`https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent`, {
    method: "POST",
    headers: { "Content-Type": "application/json", "x-goog-api-key": process.env.GEMINI_API_KEY || "" },
    body: JSON.stringify(body),
    signal: AbortSignal.timeout(20_000),
  });
}

// Tries each model in turn when one is overloaded, rate limited or missing.
async function gemini({ system, contents, tools, config = {} }) {
  let lastErr = new Error("No Gemini model configured");

  for (const model of MODELS) {
    const thinking = thinkingFor(model);
    const body = {
      systemInstruction: { parts: [{ text: system }] },
      contents,
      generationConfig: { ...config, ...(thinking ? { thinkingConfig: thinking } : {}) },
    };
    if (tools) body.tools = tools;

    let r;
    let j;
    const started = Date.now();
    try {
      r = await send(model, body);
      j = await r.json();
      // Not every model accepts the thinking setting; retry once without it.
      if (r.status === 400 && thinking && /think/i.test(j.error?.message || "")) {
        delete body.generationConfig.thinkingConfig;
        r = await send(model, body);
        j = await r.json();
      }
    } catch (e) {
      lastErr = e;
      console.warn(`[${model}] ${e.name}: ${e.message}`);
      continue;
    }
    console.log(`[${model}] ${r.status} in ${Date.now() - started}ms`);

    if (r.ok) return j;

    lastErr = new Error(j.error?.message || `Gemini error ${r.status}`);
    console.warn(`[${model}] ${r.status}: ${String(lastErr.message).slice(0, 120)}`);
    if (![404, 429, 500, 503].includes(r.status)) throw lastErr;
  }
  throw lastErr;
}

function runTool(name, args, state) {
  if (name === "get_order_details") return getOrderDetails(args.order_id, state);
  if (name === "cancel_order") return cancelOrder(args.order_id, state);
  return { error: "UNKNOWN_TOOL" };
}

// Gemini wants strictly alternating turns that start with the user.
function toContents(messages) {
  const out = [];
  for (const m of (Array.isArray(messages) ? messages : []).slice(-30)) {
    const text = String(m?.text || "").trim().slice(0, 800);
    if (!text) continue;
    const role = m.role === "user" ? "user" : "model";
    if (!out.length && role !== "user") continue;
    if (out.length && out[out.length - 1].role === role) out[out.length - 1].parts[0].text += " " + text;
    else out.push({ role, parts: [{ text }] });
  }
  return out;
}

app.get("/api/orders", (_, res) => res.json(Object.values(ORDERS)));

// One customer turn: model -> tools -> model, until there is a spoken reply.
app.post("/api/chat", rateLimit(60), async (req, res) => {
  try {
    const contents = toContents(req.body.messages);
    if (!contents.length) return res.status(400).json({ error: "No customer message" });

    const state = sessionState(req.body.sessionId);
    const toolCalls = [];

    for (let round = 0; round < 4; round++) {
      const j = await gemini({
        system: SYSTEM_PROMPT,
        contents,
        tools: [{ functionDeclarations: declarations }],
        config: { maxOutputTokens: 300 },
      });
      const content = j.candidates?.[0]?.content;
      const parts = content?.parts || [];
      const calls = parts.filter((p) => p.functionCall);

      if (!calls.length) {
        const reply = parts.map((p) => p.text || "").join("").trim();
        return res.json({ reply: reply || "Sorry, could you please say that again?", toolCalls });
      }

      contents.push(content);
      contents.push({
        role: "user",
        parts: calls.map(({ functionCall: { name, args = {} } }) => {
          const result = runTool(name, args, state);
          toolCalls.push({ name, args, result });
          return { functionResponse: { name, response: { result } } };
        }),
      });
    }
    res.json({ reply: "Sorry, I ran into a problem. Could you please repeat that?", toolCalls });
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: String(e.message || e) });
  }
});

// Used only if the model can't produce a summary, so the report still shows something useful.
function fallbackSummary(transcript, reason) {
  const text = transcript.map((t) => t.text).join(" ");
  const id = text.match(/ORD-\d+/i);
  return {
    customer_intent: "OTHER",
    order_id: id ? id[0].toUpperCase() : null,
    resolution_status: "UNKNOWN",
    actions_taken: transcript.filter((t) => t.role === "tool").map((t) => t.text.split(" → ")[0]),
    call_summary: "An automatic summary could not be generated for this call. See the transcript for details.",
    error: "SUMMARY_FAILED",
    detail: reason,
  };
}

app.post("/api/summary", rateLimit(20), async (req, res) => {
  const transcript = (Array.isArray(req.body.transcript) ? req.body.transcript : [])
    .filter((t) => t && t.text)
    .slice(-80)
    .map((t) => ({ role: String(t.role || "customer"), text: String(t.text).slice(0, 800) }));

  try {
    const text = transcript.map((t) => `${t.role.toUpperCase()}: ${t.text}`).join("\n") || "(empty call)";
    const j = await gemini({
      system: SUMMARY_PROMPT,
      contents: [{ role: "user", parts: [{ text }] }],
      config: { responseMimeType: "application/json" },
    });
    const raw = (j.candidates?.[0]?.content?.parts || []).map((p) => p.text || "").join("");
    const json = raw.slice(raw.indexOf("{"), raw.lastIndexOf("}") + 1);
    res.json(JSON.parse(json));
  } catch (e) {
    console.error(e);
    res.json(fallbackSummary(transcript, String(e.message || e)));
  }
});

app.listen(PORT, () => console.log(`Aria is running on http://localhost:${PORT}`));
