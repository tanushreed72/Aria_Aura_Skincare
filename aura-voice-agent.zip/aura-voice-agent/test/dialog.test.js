import { test } from "node:test";
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import vm from "node:vm";

const ctx = {};
vm.runInNewContext(readFileSync(new URL("../public/dialog.js", import.meta.url), "utf8"), ctx);
const { classifyClosing, looksLikeEcho } = ctx.Dialog;

const cases = {
  no: [
    "no", "No.", "nope", "No, that's all", "no thank you", "No thanks", "that's it", "That's all",
    "nothing else", "I'm good", "No, I'm good thanks", "nahi", "nahi bas", "bas itna hi hai",
    "thank you", "no that's it thank you so much", "Goodbye", "kuch nahi dhanyavad",
  ],
  yes: ["yes", "Yes please", "yeah", "sure", "haan ji", "yes I have another question", "yep"],
  unclear: ["hmm", "Hmm, actually...", "um", "okay", "let me think", "uh wait a second"],
  other: [
    "Yes, can you tell me about COD?",
    "No, I want to cancel another order",
    "No wait I have one more question",
    "Is COD available?",
    "where is order one oh one",
    "Is there anything else I can help you with today?",
    "",
  ],
};

for (const [expected, list] of Object.entries(cases)) {
  test(`closing answer is "${expected}"`, () => {
    for (const phrase of list) assert.equal(classifyClosing(phrase), expected, JSON.stringify(phrase));
  });
}

const ariaSaid = [
  "I can share the items in your order or estimated delivery details if that helps you decide. Is there anything else I can help you with today?",
];

test("recognises Aria's own voice picked up by the mic", () => {
  assert.ok(looksLikeEcho("I can share EI things in your order or estimated delivery details", ariaSaid, { minWords: 2, ratio: 0.6 }));
  assert.ok(looksLikeEcho("Is there anything else I can help you with today", ariaSaid));
});

test("does not flag a genuine customer request", () => {
  assert.equal(looksLikeEcho("Where is my order ORD-101", ariaSaid), false);
  assert.equal(looksLikeEcho("no", ariaSaid), false);
  assert.equal(looksLikeEcho("Actually, wait", ariaSaid, { minWords: 2, ratio: 0.6 }), false);
});
