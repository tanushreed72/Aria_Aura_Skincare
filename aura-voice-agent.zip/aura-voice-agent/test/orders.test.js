import { test } from "node:test";
import assert from "node:assert/strict";
import { getOrderDetails, cancelOrder, normalizeOrderId } from "../orders.js";

test("order ids are normalised from speech-style input", () => {
  assert.equal(normalizeOrderId("ord 101"), "ORD-101");
  assert.equal(normalizeOrderId("O R D 1 0 1"), "ORD-101");
  assert.equal(normalizeOrderId("hello"), null);
});

test("unknown and missing ids are reported, not invented", () => {
  assert.deepEqual(getOrderDetails("ORD-999"), { found: false, error: "ORDER_NOT_FOUND", order_id: "ORD-999" });
  assert.equal(getOrderDetails("").error, "MISSING_OR_UNREADABLE_ORDER_ID");
});

test("ORD-102 is outside the 7 day return window", () => {
  const o = getOrderDetails("ORD-102");
  assert.equal(o.policy.return_eligible, false);
  assert.match(o.policy.return_note, /Do NOT promise/);
});

test("only Processing orders can be cancelled", () => {
  const state = {};
  assert.equal(cancelOrder("ORD-101", state).success, false);
  assert.equal(cancelOrder("ORD-102", state).success, false);
  assert.equal(cancelOrder("ORD-103", state).success, true);
  assert.equal(getOrderDetails("ORD-103", state).status, "Cancelled");
  assert.equal(cancelOrder("ORD-103", state).success, false);
});

test("a cancellation in one call does not leak into the next", () => {
  const first = {};
  cancelOrder("ORD-103", first);
  assert.equal(getOrderDetails("ORD-103", {}).status, "Processing");
});
